// DOM Elements
const startBtn = document.getElementById("start-btn");
const targetDateInput = document.getElementById("target-date");
const daysDisplay = document.getElementById("days");
const hoursDisplay = document.getElementById("hours");
const minutesDisplay = document.getElementById("minutes");
const secondsDisplay = document.getElementById("seconds");
const message = document.getElementById("message");

let countdownInterval; // Variable to store the countdown interval

// Function to start the countdown
function startCountdown() {
    const targetDate = new Date(targetDateInput.value).getTime(); // Get the target date in milliseconds

    // Check if the input is valid
    if (isNaN(targetDate)) {
        alert("Please enter a valid date and time."); // Show an alert if the input is invalid
        return;
    }

    // Clear any existing countdown interval
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }

    // Update the countdown every second
    countdownInterval = setInterval(() => {
        const now = new Date().getTime(); // Get the current date and time in milliseconds
        const timeRemaining = targetDate - now; // Calculate the remaining time in milliseconds

        // If the countdown reaches zero, stop the interval and display a message
        if (timeRemaining <= 0) {
            clearInterval(countdownInterval);
            message.innerText = "Countdown finished!";
            updateDisplay(0, 0, 0, 0); // Update the display to show zeros
            return;
        }

        // Calculate days, hours, minutes, and seconds from the remaining time
        const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24)); // Convert milliseconds to days
        const hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)); // Convert to hours
        const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60)); // Convert to minutes
        const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000); // Convert to seconds

        // Update the display with the calculated time
        updateDisplay(days, hours, minutes, seconds);
    }, 1000); // Update every 1000 milliseconds (1 second)
}

// Function to update the countdown display
function updateDisplay(days, hours, minutes, seconds) {
    daysDisplay.innerText = String(days).padStart(2, "0"); // Ensure 2 digits
    hoursDisplay.innerText = String(hours).padStart(2, "0");
    minutesDisplay.innerText = String(minutes).padStart(2, "0");
    secondsDisplay.innerText = String(seconds).padStart(2, "0");
}

// Add an event listener to the "Start" button
startBtn.addEventListener("click", startCountdown);